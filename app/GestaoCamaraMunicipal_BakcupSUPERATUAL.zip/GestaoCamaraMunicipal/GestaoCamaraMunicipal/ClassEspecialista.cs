﻿namespace GestaoCamaraMunicipal
{
    public partial class Especialista
    {
        public override string ToString()
        {
            return string.Format("{0}", Funcionario);
        }
    }
}
