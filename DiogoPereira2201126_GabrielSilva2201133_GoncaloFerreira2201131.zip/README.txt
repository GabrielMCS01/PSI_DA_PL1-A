## Membros da Equipa

* Diogo Pereira Nº 2201126
* Gabriel Silva Nº 2201133
* Gonçalo Ferreira Nº 2201131


Processos de instalação e configurações iniciais do projeto

1º - Descarregar o ficheiro "DiogoPereira2201126_GabrielSilva2201133_GoncaloFerreira2201131.zip"

2º - Extrair o ficheiro descarregado anteriormente

3º - Abrir no Visual Studio o ficheiro "GestaoCamaraMunicipal.sln" no caminho "PSI_DA_PL1-A\app\GestaoCamaraMunicipal"

4º - No Visual Studio na TAB "Exibir" ou "View" selecionar a opção "SQL Server Object Explorer"

5º - Criar uma Base de dados com o nome "GestaoMunicipal" na TAB aberta anteriormente

6º - Abrir o ficheiro "GestaoCamaraMunicipal.edmx.sql" e executá-lo selecionando a Base de Dados criada anteriormente 
na TAB que irá aparecer quando se executa o Script 

7º - Executar a aplicação