﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestaoCamaraMunicipal
{
    public partial class Form1 : Form
    {
        private GestaoCamaraMunicipalContainer camaraMunicipal;
        public Form1()
        {
            InitializeComponent();
            camaraMunicipal = new GestaoCamaraMunicipalContainer();

        }
    }
}
